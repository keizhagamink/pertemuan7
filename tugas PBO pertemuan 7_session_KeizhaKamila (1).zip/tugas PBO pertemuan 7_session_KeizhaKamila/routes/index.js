const express = require('express');
const router = express.Router();

// Halaman utama
router.get('/', (req, res) => {
    res.render('index', { loggedIn: req.session.loggedin, username: req.session.username });
});

// Halaman login
router.get('/login', (req, res) => {
    res.render('login');
});

// Proses login
router.post('/login', (req, res) => {
    const { username, password } = req.body;
    const user = req.app.locals.users.find(u => u.username === username && u.password === password);

    if (user) {
        req.session.username = user.username;
        req.session.loggedin = true;
        res.redirect('/');
    } else {
        res.send('Username atau password salah!');
    }
});

// Halaman edit username (GET)
router.get('/edit-username', (req, res) => {
    if (req.session.loggedin) {
        res.render('edit-username', { username: req.session.username });
    } else {
        res.redirect('/login');
    }
});

// Proses edit username (POST)
router.post('/edit-username', (req, res) => {
    if (req.session.loggedin) {
        const newUsername = req.body.username;
        const user = req.app.locals.users.find(u => u.username === req.session.username);

        if (user) {
            user.username = newUsername;
            req.session.username = newUsername;
            res.redirect('/');
        } else {
            res.send('Terjadi kesalahan saat mengubah username.');
        }
    } else {
        res.redirect('/login');
    }
});

// Halaman lupa username
router.get('/forgot-username', (req, res) => {
    res.render('forgot-username');
});

router.post('/forgot-username', (req, res) => {
    const email = req.body.email;
    const user = req.app.locals.users.find(u => u.email === email);

    if (user) {
        res.send(`Username Anda adalah: ${user.username}`);
    } else {
        res.send('Email tidak ditemukan!');
    }
});

// Halaman lupa password
router.get('/forgot-password', (req, res) => {
    res.render('forgot-password');
});

router.post('/forgot-password', (req, res) => {
    const username = req.body.username;
    const user = req.app.locals.users.find(u => u.username === username);

    if (user) {
        res.send(`Password Anda adalah: ${user.password}`); // Ini untuk demo, seharusnya tidak mengungkapkan password
    } else {
        res.send('Username tidak ditemukan!');
    }
});

// Logout
router.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/');
});

module.exports = router;
