const express = require('express');
const session = require('express-session');
const path = require('path');
const app = express();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');

// Simulasi database (array untuk menyimpan data user)
let users = [
    { id: 1, username: 'user1', password: 'password1', email: 'user1@example.com' },
    { id: 2, username: 'user2', password: 'password2', email: 'user2@example.com' }
];

// Konfigurasi session
app.use(session({
    secret: 'secretKey',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));

// Routes
const indexRouter = require('./routes/index');
app.use('/', indexRouter);

// Simpan data pengguna
app.locals.users = users;

// Jalankan server
app.listen(3000, () => {
    console.log('Server berjalan di http://localhost:3000');
});
